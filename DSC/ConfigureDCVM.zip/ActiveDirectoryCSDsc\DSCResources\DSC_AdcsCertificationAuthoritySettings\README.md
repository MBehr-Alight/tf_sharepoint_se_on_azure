# Description

This resource can be used to configure the advanced settings of an Active
Directory Certificate Services instance. The Active Directory Certificate Services
feature should have been enabled and a Certificate Authority installed.

For more detailed information and examples of setting the values for this resource
please read [this blog series](https://blogs.technet.microsoft.com/xdot509/2013/03/22/installing-a-two-tier-pki-hierarchy-in-windows-server-2012-wrap-up/).
