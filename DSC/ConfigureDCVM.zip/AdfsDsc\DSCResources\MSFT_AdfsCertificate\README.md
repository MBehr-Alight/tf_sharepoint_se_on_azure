# Description

The AdfsCertificate Dsc resource manages certificate that AD FS uses to sign, decrypt, or secure
communications.
