# Description

The AdfsGlobalAuthenticationPolicy DSC resource manages the global authentication policy, which includes the
providers currently allowed as additional providers in the AdditionalAuthenticationProvider property.
