# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to set the global certificate settings for the local farm.
These settings will be used by the Certificate Management solution when creating
new certificates.
